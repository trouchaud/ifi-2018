package io.codeka.handcraft.servlet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.codeka.handcraft.annotations.Controller;
import io.codeka.handcraft.annotations.RequestMapping;
import io.codeka.handcraft.controllers.HelloController;
import io.codeka.handcraft.controllers.PokemonController;

@WebServlet(urlPatterns = "/*", loadOnStartup = 1)
public class DispatcherServlet extends HttpServlet {

    private Map<String, Method> mappings = new HashMap<>();

    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Getting request for " + req.getRequestURI());

        var requestUri = req.getRequestURI();

        var method = this.mappings.get(requestUri);

        if(method == null){
            var message = "no mapping found for request uri " + requestUri;
            System.out.println(message);
            resp.sendError(404, message);
            return;
        }

        try {
            var controllerClass = method.getDeclaringClass();
            var controllerInstance = controllerClass.newInstance();

            var writer = resp.getWriter();
            if(method.getParameterCount() == 0){
                var result = method.invoke(controllerInstance);
                writer.print(result.toString());
            }
            else{
                var result = method.invoke(controllerInstance, req.getParameterMap());
                writer.print(objectMapper.writeValueAsString(result));
            }
        } catch (InvocationTargetException e) {
            var message = "exception when calling method " + method.getName() + " : " + e.getTargetException().getMessage();
            System.out.println(message);
            resp.sendError(500, message);
        } catch (Exception e) {
            var message = "exception when calling method " + method.getName() + " : " + e.getMessage();
            System.out.println(message);
            resp.sendError(500, message);
        }
    }

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);

        this.registerController(HelloController.class);
        this.registerController(PokemonController.class);
    }

    protected void registerController(Class controllerClass){
        System.out.println("Analysing class " + controllerClass.getName());
        if(controllerClass.getAnnotation(Controller.class) == null){
            throw new IllegalArgumentException(controllerClass + " is not annotated");
        }

        Arrays.stream(controllerClass.getDeclaredMethods())
                .filter(method -> method.isAnnotationPresent(RequestMapping.class))
                .filter(method -> ! method.getReturnType().equals(Void.TYPE))
                .forEach(method -> registerMethod(controllerClass, method));
    }

    protected void registerMethod(Object controller, Method method) {
        System.out.println("Analysing method " + method.getName());

        var annotation = method.getDeclaredAnnotation(RequestMapping.class);
        var mapping = annotation.uri();

        this.mappings.put(mapping, method);
    }

    protected Map<String, Method> getMappings(){
        return this.mappings;
    }

    protected Method getMappingForUri(String uri){
        return this.mappings.get(uri);
    }
}


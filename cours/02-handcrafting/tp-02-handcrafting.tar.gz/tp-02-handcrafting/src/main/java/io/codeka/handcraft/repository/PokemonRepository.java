package io.codeka.handcraft.repository;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.codeka.handcraft.bo.Pokemon;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Repository loading data from https://pokeapi.co/
 */
public class PokemonRepository {

    private HttpClient httpClient; //<1>

    private ObjectMapper objectMapper; //<2>

    public PokemonRepository(){
        httpClient = HttpClient.newBuilder() //<1>
            .followRedirects(HttpClient.Redirect.ALWAYS) //<1>
            .build();

        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false); // <2>
    }

    public Pokemon getPokemonFromId(int id){
        System.out.println("Loading Pokemon information for Pokemon id " + id);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://pokeapi.co/api/v2/pokemon/" + id)) //<3>
                .GET()
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return objectMapper.readValue(response.body(), Pokemon.class);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to load Pokemon of id " + id);
        }
    }

    public Pokemon getPokemonFromName(String name){
        System.out.println("Loading Pokemon information for Pokemon name " + name);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://pokeapi.co/api/v2/pokemon/" + name)) //<3>
                .GET()
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return objectMapper.readValue(response.body(), Pokemon.class);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            throw new RuntimeException("Unable to load Pokemon of name " + name);
        }
    }

    public void setHttpClient(HttpClient httpClient) {
        this.httpClient = httpClient;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }
}

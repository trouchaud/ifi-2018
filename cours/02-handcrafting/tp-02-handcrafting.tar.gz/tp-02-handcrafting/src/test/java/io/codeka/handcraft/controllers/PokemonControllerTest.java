package io.codeka.handcraft.controllers;

import java.util.Map;

import io.codeka.handcraft.bo.Pokemon;
import io.codeka.handcraft.repository.PokemonRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PokemonControllerTest {

    @InjectMocks
    PokemonController controller;

    @Mock
    PokemonRepository pokemonRepository;

    @BeforeEach
    void init(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void getPokemon_shouldRequireAParameter(){
        var exception = assertThrows(IllegalArgumentException.class, () -> controller.getPokemon(null));
        assertEquals("parameters should not be empty", exception.getMessage());
    }

    @Test
    void getPokemon_shouldRequireAKnownParameter(){
        var parameters = Map.of("test", new String[]{"25"});
        var exception = assertThrows(IllegalArgumentException.class, () -> controller.getPokemon(parameters));
        assertEquals("unknown parameter", exception.getMessage());
    }

    @Test
    void getPokemon_withAnIdParameter_shouldReturnAPokemon(){
        var pikachu = new Pokemon();
        pikachu.setId(25);
        pikachu.setName("pikachu");
        when(pokemonRepository.getPokemonFromId(25)).thenReturn(pikachu);

        var parameters = Map.of("id", new String[]{"25"});
        var pokemon = controller.getPokemon(parameters);
        assertNotNull(pokemon);
        assertEquals(25, pokemon.getId());
        assertEquals("pikachu", pokemon.getName());

        verify(pokemonRepository).getPokemonFromId(25);
        verifyNoMoreInteractions(pokemonRepository);
    }

    @Test
    void getPokemon_withANameParameter_shouldReturnAPokemon(){
        var zapdos = new Pokemon();
        zapdos.setId(145);
        zapdos.setName("zapdos");
        when(pokemonRepository.getPokemonFromName("zapdos")).thenReturn(zapdos);

        var parameters = Map.of("name", new String[]{"zapdos"});
        var pokemon = controller.getPokemon(parameters);
        assertNotNull(pokemon);
        assertEquals(145, pokemon.getId());
        assertEquals("zapdos", pokemon.getName());

        verify(pokemonRepository).getPokemonFromName("zapdos");
        verifyNoMoreInteractions(pokemonRepository);
    }

}
package io.codeka.handcraft.controllers;

import java.util.Map;

import io.codeka.handcraft.annotations.Controller;
import io.codeka.handcraft.annotations.RequestMapping;
import io.codeka.handcraft.bo.Pokemon;
import io.codeka.handcraft.repository.PokemonRepository;
import io.codeka.handcraft.service.PokemonService;

@Controller
public class PokemonController {

    private PokemonRepository repository = new PokemonRepository();

    @RequestMapping(uri="/pokemon")
    public Pokemon getPokemon(Map<String,String[]> parameters){
        if(parameters == null){
            throw new IllegalArgumentException("parameters should not be empty");
        }

        if(parameters.containsKey("id")){
            var id = Integer.parseInt(parameters.get("id")[0]);
            return repository.getPokemonFromId(id);
        }
        else if(parameters.containsKey("name")){
            var name = parameters.get("name")[0];
            return repository.getPokemonFromName(name);
        }
        else {
            throw new IllegalArgumentException("unknown parameter");
        }
    }

}

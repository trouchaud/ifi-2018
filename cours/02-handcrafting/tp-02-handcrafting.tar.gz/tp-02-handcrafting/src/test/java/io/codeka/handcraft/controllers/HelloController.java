package io.codeka.handcraft.controllers;

import io.codeka.handcraft.annotations.Controller;
import io.codeka.handcraft.annotations.RequestMapping;

@Controller
public class HelloController {

    @RequestMapping(uri="/hello")
    public String sayHello(){
        return "Hello World !";
    }

    @RequestMapping(uri="/bye")
    public String sayGoodBye(){
        return "Goodbye !";
    }

    @RequestMapping(uri="/boum")
    public String explode(){
        throw new RuntimeException("Explosion !");
    }

}

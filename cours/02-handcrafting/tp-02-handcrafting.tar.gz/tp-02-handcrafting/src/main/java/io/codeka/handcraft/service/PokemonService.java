package io.codeka.handcraft.service;

import io.codeka.handcraft.bo.Pokemon;
import io.codeka.handcraft.repository.PokemonRepository;

public class PokemonService {

    private PokemonRepository pokemonRepository;

    public void setPokemonRepository(PokemonRepository pokemonRepository) {
        this.pokemonRepository = pokemonRepository;
    }

    public Pokemon getPokemon(int id) {
        return this.pokemonRepository.getPokemonFromId(id);
    }
}

package io.codeka.handcraft.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.codeka.handcraft.bo.Pokemon;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class PokemonRepositoryTest {

    @Test
    void getPokemon_callsHttpClientApi() throws IOException, InterruptedException {
        var repo = new PokemonRepository();

        var httpClient = mock(HttpClient.class);
        var objectMapper = mock(ObjectMapper.class);

        repo.setHttpClient(httpClient);
        repo.setObjectMapper(objectMapper);

        var httpResponse = mock(HttpResponse.class);
        when(httpClient.send(any(), any())).thenReturn(httpResponse);
        when(httpResponse.statusCode()).thenReturn(200);
        when(httpResponse.body()).thenReturn("{\"id\":\"25\",\"name\":\"pikachu\"}");

        repo.getPokemonFromId(25);

        var httpRequestCaptor = ArgumentCaptor.forClass(HttpRequest.class);
        verify(httpClient).send(httpRequestCaptor.capture(), eq(HttpResponse.BodyHandlers.ofString()));

        var httpRequest = httpRequestCaptor.getValue();
        assertEquals("GET", httpRequest.method());
        assertEquals("https://pokeapi.co/api/v2/pokemon/25", httpRequest.uri().toString());

        verify(objectMapper).readValue("{\"id\":\"25\",\"name\":\"pikachu\"}", Pokemon.class);
    }

    @Test
    void getPokemon_callsHttpClientName() throws IOException, InterruptedException {
        var repo = new PokemonRepository();

        var httpClient = mock(HttpClient.class);
        var objectMapper = mock(ObjectMapper.class);

        repo.setHttpClient(httpClient);
        repo.setObjectMapper(objectMapper);

        var httpResponse = mock(HttpResponse.class);
        when(httpClient.send(any(), any())).thenReturn(httpResponse);
        when(httpResponse.statusCode()).thenReturn(200);
        when(httpResponse.body()).thenReturn("{\"id\":\"145\",\"name\":\"zapdos\"}");
        repo.getPokemonFromName("zapdos");

        var httpRequestCaptor = ArgumentCaptor.forClass(HttpRequest.class);
        verify(httpClient).send(httpRequestCaptor.capture(), eq(HttpResponse.BodyHandlers.ofString()));

        var httpRequest = httpRequestCaptor.getValue();
        assertEquals("GET", httpRequest.method());
        assertEquals("https://pokeapi.co/api/v2/pokemon/zapdos", httpRequest.uri().toString());

        verify(objectMapper).readValue("{\"id\":\"145\",\"name\":\"zapdos\"}", Pokemon.class);
    }

    @Test
    void getPokemonFromId() {
        var repo = new PokemonRepository();
        var pokemon = repo.getPokemonFromId(25);

        assertEquals(25, pokemon.getId());
        assertEquals("pikachu", pokemon.getName());
        assertEquals("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png", pokemon.getSprites().getFront_default());
    }

    @Test
    void getPokemonFromName() {
        var repo = new PokemonRepository();
        var pokemon = repo.getPokemonFromName("zapdos");

        assertEquals(145, pokemon.getId());
        assertEquals("zapdos", pokemon.getName());
        assertEquals("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/145.png", pokemon.getSprites().getFront_default());
    }

}
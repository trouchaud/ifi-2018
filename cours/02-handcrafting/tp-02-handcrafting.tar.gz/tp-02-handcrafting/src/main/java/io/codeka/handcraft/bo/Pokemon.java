package io.codeka.handcraft.bo;

public class Pokemon {

    private int id;

    private String name;

    private Sprites sprites;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Sprites getSprites() {
        return sprites;
    }

    public class Sprites{
        private String front_default;

        public String getFront_default() {
            return front_default;
        }
    }

}

